splashscreentime = 2

TimeManger = {
    zhonggaoFadeIn = 1,
    zhonggaoStay = 2,
    zhonggaoFadeOut = 3,
    StartBGFadeIn = 6,
    --   ShiftFadeIn = 7

    End = 7
}
