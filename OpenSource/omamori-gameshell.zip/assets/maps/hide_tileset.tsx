<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="hide_tileset" tilewidth="32" tileheight="32" tilecount="128" columns="16">
 <image source="../images/hide_battlefield_tileset.png" width="512" height="256"/>
 <terraintypes>
  <terrain name="Bounds" tile="8"/>
 </terraintypes>
 <tile id="0" type="Path"/>
 <tile id="4" type="Grass"/>
 <tile id="5" type="Grass"/>
 <tile id="6" type="Grass"/>
 <tile id="7" type="Grass"/>
 <tile id="8" terrain=",,,0"/>
 <tile id="9" terrain=",,0,0"/>
 <tile id="10" terrain=",,0,"/>
 <tile id="11" terrain="0,0,0,"/>
 <tile id="12" terrain="0,0,,0"/>
 <tile id="21" type="Mountains"/>
 <tile id="22" type="Lantern"/>
 <tile id="23" type="Mountains"/>
 <tile id="24" terrain=",0,,0"/>
 <tile id="25" terrain="0,0,0,0"/>
 <tile id="26" terrain="0,,0,"/>
 <tile id="27" terrain="0,,0,0"/>
 <tile id="28" terrain=",0,0,0"/>
 <tile id="37" type="Mountains"/>
 <tile id="38">
  <properties>
   <property name="shadowHeight" type="int" value="7"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="14"/>
  </properties>
 </tile>
 <tile id="39" type="Mountains"/>
 <tile id="40" terrain=",0,,"/>
 <tile id="41" terrain="0,0,,"/>
 <tile id="42" terrain="0,,,"/>
 <tile id="52" type="Mountains"/>
 <tile id="53" type="Mountains"/>
 <tile id="55" type="Mountains"/>
 <tile id="56">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="shadowHeight" type="int" value="4"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="6"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="shadowHeight" type="int" value="6"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="shadowHeight" type="int" value="6"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="68" type="Mountains"/>
 <tile id="69" type="Mountains"/>
 <tile id="70" type="Mountains"/>
 <tile id="72">
  <properties>
   <property name="shadowHeight" type="int" value="7"/>
   <property name="shadowOffsetX" type="int" value="16"/>
   <property name="shadowWidth" type="int" value="41"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="shadowHeight" type="int" value="7"/>
   <property name="shadowOffsetX" type="int" value="-16"/>
   <property name="shadowWidth" type="int" value="41"/>
  </properties>
 </tile>
 <tile id="76" type="Mountains"/>
 <tile id="77" type="Mountains"/>
 <tile id="78" type="Mountains"/>
 <tile id="125" type="Mountains"/>
 <tile id="126" type="Mountains"/>
 <tile id="127" type="Mountains"/>
</tileset>
