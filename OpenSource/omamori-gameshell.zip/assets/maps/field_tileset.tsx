<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="battlefield_tileset" tilewidth="32" tileheight="32" tilecount="128" columns="16">
 <image source="../images/battlefield_tileset.png" width="512" height="256"/>
 <terraintypes>
  <terrain name="Bounds" tile="6"/>
  <terrain name="Forest" tile="0"/>
 </terraintypes>
 <tile id="0" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="1" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="3" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="4" type="Grass">
  <properties>
   <property name="walk_cost" type="float" value="1.5"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="5" type="Grass">
  <properties>
   <property name="walk_cost" type="float" value="1.5"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="6" type="Grass">
  <properties>
   <property name="walk_cost" type="float" value="1.5"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="7" type="Grass">
  <properties>
   <property name="walk_cost" type="float" value="1.5"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="8" terrain=",,,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="9" terrain=",,0,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="10" terrain=",,0,">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="11" terrain="0,0,0,">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="12" terrain="0,0,,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="16" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="17" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="18" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="19" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="21" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="22" type="Lantern"/>
 <tile id="23">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
  </properties>
 </tile>
 <tile id="24" terrain=",0,,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="25" terrain="0,0,0,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="26" terrain="0,,0,">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="27" terrain="0,,0,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="28" terrain=",0,0,0">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="29" type="Trees"/>
 <tile id="30" type="Houses"/>
 <tile id="31" type="Lantern"/>
 <tile id="32">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="37" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="shadowHeight" type="int" value="7"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="14"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
  </properties>
 </tile>
 <tile id="40" terrain=",0,,">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="41" terrain="0,0,,">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="42" terrain="0,,,">
  <properties>
   <property name="selectable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="52" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="53" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="walkable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="shadowHeight" type="int" value="4"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="6"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="shadowHeight" type="int" value="6"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="shadowHeight" type="int" value="6"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="10"/>
  </properties>
 </tile>
 <tile id="64" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="65" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="66" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="67" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="68" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="69" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="70" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="shadowHeight" type="int" value="7"/>
   <property name="shadowOffsetX" type="int" value="16"/>
   <property name="shadowWidth" type="int" value="41"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="shadowHeight" type="int" value="7"/>
   <property name="shadowOffsetX" type="int" value="-16"/>
   <property name="shadowWidth" type="int" value="41"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
  </properties>
 </tile>
 <tile id="78">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
  </properties>
 </tile>
 <tile id="80" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="81" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="82" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="83" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="84" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="85" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="86" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="87" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="88" type="Path" terrain=",,,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="89" type="Path" terrain=",,1,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="90" type="Path" terrain=",,1,">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="91" type="Path" terrain="1,1,1,">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="92" type="Path" terrain="1,1,,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="93" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="94" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="96" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="97" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="98" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="99" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="100" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="101" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="102" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="103" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="104" type="Path" terrain=",1,,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="105" type="Path" terrain="1,1,1,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="106" type="Path" terrain="1,,1,">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="107" type="Path" terrain="1,,1,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="108" type="Path" terrain=",1,1,1">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="109" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="110" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="112" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="113" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="114" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="115" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="116" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="117" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="118" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="119" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="120" type="Path" terrain=",1,,">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="121" type="Path" terrain="1,1,,">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="122" type="Path" terrain="1,,,">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="123" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="124" type="Path">
  <properties>
   <property name="walk_cost" type="float" value="1"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="125" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="126" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="127" type="Mountains">
  <properties>
   <property name="walk_cost" type="float" value="2"/>
   <property name="walkable" type="bool" value="true"/>
  </properties>
 </tile>
 <wangsets>
  <wangset name="New Wang Set" tile="97">
   <wangedgecolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangedgecolor name="" color="#00ff00" tile="-1" probability="1"/>
   <wangcornercolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangcornercolor name="" color="#00ff00" tile="-1" probability="1"/>
   <wangtile tileid="80" wangid="0x1002001"/>
   <wangtile tileid="81" wangid="0x202001"/>
   <wangtile tileid="82" wangid="0x200101"/>
   <wangtile tileid="83" wangid="0x1000101"/>
   <wangtile tileid="84" wangid="0x1000001"/>
   <wangtile tileid="85" wangid="0x1"/>
   <wangtile tileid="86" wangid="0x101"/>
   <wangtile tileid="87" wangid="0x2000"/>
   <wangtile tileid="88" wangid="0x200000"/>
   <wangtile tileid="89" wangid="0x10020"/>
   <wangtile tileid="90" wangid="0x20010000"/>
   <wangtile tileid="91" wangid="0x202020"/>
   <wangtile tileid="92" wangid="0x20202000"/>
   <wangtile tileid="93" wangid="0x2020"/>
   <wangtile tileid="94" wangid="0x20000020"/>
   <wangtile tileid="96" wangid="0x1002020"/>
   <wangtile tileid="97" wangid="0x20202020"/>
   <wangtile tileid="98" wangid="0x20200100"/>
   <wangtile tileid="99" wangid="0x1000100"/>
   <wangtile tileid="100" wangid="0x1000000"/>
   <wangtile tileid="102" wangid="0x100"/>
   <wangtile tileid="103" wangid="0x20"/>
   <wangtile tileid="104" wangid="0x20000000"/>
   <wangtile tileid="105" wangid="0x200100"/>
   <wangtile tileid="106" wangid="0x100"/>
   <wangtile tileid="107" wangid="0x20002020"/>
   <wangtile tileid="108" wangid="0x20200020"/>
   <wangtile tileid="109" wangid="0x20200000"/>
   <wangtile tileid="110" wangid="0x202000"/>
   <wangtile tileid="112" wangid="0x1010020"/>
   <wangtile tileid="113" wangid="0x20010020"/>
   <wangtile tileid="114" wangid="0x20010100"/>
   <wangtile tileid="115" wangid="0x1010100"/>
   <wangtile tileid="116" wangid="0x1010000"/>
   <wangtile tileid="117" wangid="0x10000"/>
   <wangtile tileid="118" wangid="0x10100"/>
   <wangtile tileid="119" wangid="0x2001"/>
   <wangtile tileid="120" wangid="0x200001"/>
   <wangtile tileid="121" wangid="0x1002000"/>
   <wangtile tileid="122" wangid="0x1000020"/>
   <wangtile tileid="123" wangid="0x200020"/>
   <wangtile tileid="124" wangid="0x20002000"/>
  </wangset>
 </wangsets>
</tileset>
