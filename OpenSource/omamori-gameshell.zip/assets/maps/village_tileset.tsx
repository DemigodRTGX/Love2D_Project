<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="village_tileset" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../images/village_tileset.png" width="512" height="512"/>
 <terraintypes>
  <terrain name="Rocks" tile="71"/>
 </terraintypes>
 <tile id="39" terrain=",,,0"/>
 <tile id="40" terrain=",,0,0"/>
 <tile id="41" terrain=",,0,"/>
 <tile id="42" terrain="0,0,0,"/>
 <tile id="43" terrain="0,0,,0"/>
 <tile id="48">
  <properties>
   <property name="shadowHeight" type="int" value="4"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="8"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="shadowHeight" type="int" value="4"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="6"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="shadowHeight" type="int" value="6"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="14"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="shadowHeight" type="int" value="8"/>
   <property name="shadowOffsetX" type="int" value="0"/>
   <property name="shadowWidth" type="int" value="18"/>
  </properties>
 </tile>
 <tile id="55" terrain=",0,,0"/>
 <tile id="56" terrain="0,0,0,0"/>
 <tile id="57" terrain="0,,0,"/>
 <tile id="58" terrain="0,,0,0"/>
 <tile id="59" terrain=",0,0,0"/>
 <tile id="71" terrain=",0,,"/>
 <tile id="72" terrain="0,0,,"/>
 <tile id="73" terrain="0,,,"/>
</tileset>
