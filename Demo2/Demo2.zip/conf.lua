function love.conf(t)
    t.title = 'Scrolling Shooter Tutorial'
    t.vision = '0.0.1'
    t.window.width = 319
    t.window.height = 239

    -- For Windows debugging
    t.console = true
end
